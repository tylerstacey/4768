//
//  TexturedSquareViewController.h
//  Textured Square
//
//  Created by mike on 8/31/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>

@interface TexturedSquareViewController : GLKViewController

@end
