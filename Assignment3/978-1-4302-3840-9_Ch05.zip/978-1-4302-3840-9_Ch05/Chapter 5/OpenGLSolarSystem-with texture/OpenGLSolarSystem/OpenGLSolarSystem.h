//
//  OpenGLSolarSystem.h
//  OpenGLSolarSystem
//
//  Created by mike on 9/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#ifndef OpenGLSolarSystem_OpenGLSolarSystem_h
#define OpenGLSolarSystem_OpenGLSolarSystem_h

#import <OpenGLES/ES1/gl.h>
#define SS_SUNLIGHT	GL_LIGHT0	//GL uses  GL_LIGHTx
#define SS_FILLLIGHT1	GL_LIGHT1
#define SS_FILLLIGHT2	GL_LIGHT2

#endif
