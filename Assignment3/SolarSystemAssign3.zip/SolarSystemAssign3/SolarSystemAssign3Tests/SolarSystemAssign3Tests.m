//
//  SolarSystemAssign3Tests.m
//  SolarSystemAssign3Tests
//
//  Created by Mark Gauci on 2014-03-17.
//  Copyright (c) 2014 Mark Gauci. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface SolarSystemAssign3Tests : XCTestCase

@end

@implementation SolarSystemAssign3Tests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
