//
//  AppDelegate.h
//  SolarSystemAssign3
//
//  Created by Mark Gauci on 2014-03-17.
//  Copyright (c) 2014 Mark Gauci. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
