//
//  main.m
//  SolarSystemAssign3
//
//  Created by Mark Gauci on 2014-03-17.
//  Copyright (c) 2014 Mark Gauci. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
