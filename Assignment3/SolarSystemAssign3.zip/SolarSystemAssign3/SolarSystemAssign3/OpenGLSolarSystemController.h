//
//  OpenGLSolarSystemController.h
//  SolarSystemAssign3
//
//  Created by Mark Gauci on 2014-03-17.
//  Copyright (c) 2014 Mark Gauci. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Planet.h"

#define X_VALUE								0
#define Y_VALUE								1
#define Z_VALUE								2


@interface OpenGLSolarSystemController : NSObject
{
	Planet *m_Earth;
	Planet *m_Sun;
    Planet *m_Mercury;
    Planet *m_Venus;
    Planet *m_Mars;
    Planet *m_Moon;
    
	GLfloat	m_Eyeposition[3];
}

-(void)execute;
-(void)executePlanet:(Planet *)planet;
-(id)init;
-(void)initGeometry;

@end

