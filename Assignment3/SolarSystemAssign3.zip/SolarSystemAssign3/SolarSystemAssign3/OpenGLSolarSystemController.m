//
//  OpenGLSolarSystemController.m
//  SolarSystemAssign3
//
//  Created by Mark Gauci on 2014-03-17.
//  Copyright (c) 2014 Mark Gauci. All rights reserved.
//
#import "OpenGLSolarSystem.h"
#import "OpenGLSolarSystemController.h"

@implementation OpenGLSolarSystemController

-(id)init
{
	[self initGeometry];
	
	return self;
}

-(void)initGeometry
{
	m_Eyeposition[X_VALUE]=0.0;				//1
	m_Eyeposition[Y_VALUE]=2.0;
	m_Eyeposition[Z_VALUE]=10.0;
    
	m_Earth=[[Planet alloc] init:50 slices:50 radius:.3 squash:1.0 textureFile:@"Earth.png"];	//2
	[m_Earth setPositionX:0.0 Y:0.0 Z:-4.0];			//3
	
	m_Sun=[[Planet alloc] init:50 slices:50 radius:1.0 squash:1.0 textureFile:@"Sun.png"];	//4
	[m_Sun setPositionX:0.0 Y:0.0 Z:0.0];
    
    m_Moon=[[Planet alloc] init:50 slices:50 radius:.05 squash:1.0 textureFile:@"Moon.png"];
    [m_Moon setPositionX:0.0 Y:0.0 Z:-4.5];
    
    m_Mercury=[[Planet alloc] init:50 slices:50 radius:.1 squash:1.0 textureFile:@"Mercury.png"];
    [m_Mercury setPositionX:0.0 Y:0.0 Z:-1.5];
    
    m_Mars=[[Planet alloc] init:50 slices:50 radius:.3 squash:1.0 textureFile:@"Mars.png"];
    [m_Mars setPositionX:0.0 Y:0.0 Z:-6.0];
    
    m_Venus=[[Planet alloc] init:50 slices:50 radius:.2 squash:1.0 textureFile:@"Venus.png"];
    [m_Venus setPositionX:0.0 Y:0.0 Z:-2.5];
    
    
    
}
-(void)execute
{
	GLfloat paleYellow[]={1.0,1.0,0.3,1.0};			//1
	GLfloat white[]={1.0,1.0,1.0,1.0};
	GLfloat cyan[]={0.0,1.0,1.0,1.0};
	GLfloat black[]={0.0,0.0,0.0,0.0};				//2
	static GLfloat angle=0.0;
	GLfloat orbitalIncrement=0.05;				//3
	GLfloat sunPos[3]={0.0,0.0,0.0};
    
	glPushMatrix();						//4
    
	glTranslatef(-m_Eyeposition[X_VALUE],-m_Eyeposition[Y_VALUE],	//5
                 -m_Eyeposition[Z_VALUE]);
    
	glLightfv(SS_SUNLIGHT,GL_POSITION,sunPos);		//6
	glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, white);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, white);
    
	glPushMatrix();						//7
	
	angle+=orbitalIncrement;					//8
	
	glRotatef(angle,0.0,1.0,0.0);					//9
	
	[self executePlanet:m_Earth];//10
    
    angle+=orbitalIncrement+0.01;					//8
	
	glRotatef(angle,0.0,1.0,0.0);
    [self executePlanet:m_Mars];
    
    angle+=orbitalIncrement+0.02;					//8
	
	glRotatef(angle,0.0,1.0,0.0);
    [self executePlanet:m_Venus];
    
    angle+=orbitalIncrement+0.03;					//8
	
	glRotatef(angle,0.0,1.0,0.0);
    [self executePlanet:m_Mercury];

	
	glPopMatrix();						//11
	
	glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, paleYellow);	//12
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, black);	//13
    
	[self executePlanet:m_Sun];					//14
	
	glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, black);	//15
	
	glPopMatrix();						//16
}

-(void)executePlanet:(Planet *)planet
{
	GLfloat posX, posY, posZ;
    
	glPushMatrix();
    
	[planet getPositionX:&posX Y:&posY Z:&posZ];			//17
	
	glTranslatef(posX,posY,posZ);				//18
    
	[planet execute];						//19
	
	glPopMatrix();
}

-(GLKTextureInfo *)loadTexture:(NSString *)filename
{
    NSError *error;
    GLKTextureInfo *info;
    
    NSString *path=[[NSBundle mainBundle]pathForResource:filename ofType:NULL];
    
    info=[GLKTextureLoader textureWithContentsOfFile:path options:NULL error:&error];
    
    glBindTexture(GL_TEXTURE_2D, info.name);
    
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
    
    return info;
}

@end
