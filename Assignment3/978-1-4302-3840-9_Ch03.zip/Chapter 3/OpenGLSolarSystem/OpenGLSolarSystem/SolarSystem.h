//
//  SolarSystem.h
//  OpenGLSolarSystem
//
//  Created by mike on 9/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#ifndef OpenGLSolarSystem_Header_h
#define OpenGLSolarSystem_Header_h

#import <OpenGLES/ES1/gl.h>
#define SS_SUNLIGHT	GL_LIGHT0	//GL uses  GL_LIGHTx

#endif
