//
//  OpenGL_ReflectionAppDelegate.h
//  OpenGL_Reflection
//
//  Created by mike on 7/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class OpenGL_ReflectionViewController;

@interface OpenGL_ReflectionAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) OpenGL_ReflectionViewController *viewController;

@end
