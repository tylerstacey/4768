//
//  AppDelegate.h
//  TemplateOpenGL
//
//  Created by Minglun Gong on 2/24/2014.
//  Copyright (c) 2014 Minglun Gong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
