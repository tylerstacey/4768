//
//  AppDelegate.h
//  SuperCalc
//
//  Created by Tyler Stacey on 2/1/2014.
//  Copyright (c) 2014 Tyler Stacey. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
